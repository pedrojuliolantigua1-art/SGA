using Microsoft.AspNetCore.Mvc;
using SGA.Application.DTOs.Common;
using SGA.Application.DTOs.Usuarios;
using SGA.Application.Interfaces.Services;

namespace SGA.WebForo.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly IUsuarioService _usuarioService;

        public UsuarioController(IUsuarioService usuarioService)
        {
            _usuarioService = usuarioService;
        }

        // GET: UsuarioController?tipo=Estudiante&nombre=...
        public async Task<IActionResult> Index(string? tipo, string? nombre)
        {
            var usuarios = await _usuarioService.ListarTodosAsync();

            if (usuarios.EsFallo)
            {
                ViewBag.Error = usuarios.Error!.Mensaje;
                return View(new List<UsuarioResumenDto>());
            }

            var tiposGestionados = new[] { "Estudiante", "EmpleadoDocente", "EmpleadoAdministrativo" };
            IEnumerable<UsuarioResumenDto> resultado = usuarios.Valor!.Where(u => tiposGestionados.Contains(u.TipoUsuario));

            if (!string.IsNullOrWhiteSpace(tipo))
                resultado = resultado.Where(u => u.TipoUsuario == tipo);

            if (!string.IsNullOrWhiteSpace(nombre))
            {
                resultado = resultado.Where(u =>
                    (u.Nombre != null && u.Nombre.Contains(nombre, StringComparison.OrdinalIgnoreCase)) ||
                    (u.Apellido != null && u.Apellido.Contains(nombre, StringComparison.OrdinalIgnoreCase)));
            }

            ViewBag.Tipo = tipo;
            ViewBag.Nombre = nombre;
            return View(resultado.ToList());
        }

        // GET: UsuarioController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var resumen = await _usuarioService.ObtenerPorIdAsync(id);
            if (resumen.EsFallo)
            {
                ViewBag.Error = resumen.Error!.Mensaje;
                return RedirectToAction(nameof(Index));
            }

            switch (resumen.Valor!.TipoUsuario)
            {
                case "Estudiante":
                    var estudiante = await _usuarioService.ObtenerEstudiantePorIdAsync(id);
                    ViewBag.Tipo = "Estudiante";
                    return View("DetailsEstudiante", estudiante.Valor);

                case "EmpleadoDocente":
                    var docente = await _usuarioService.ObtenerDocentePorIdAsync(id);
                    ViewBag.Tipo = "EmpleadoDocente";
                    return View("DetailsDocente", docente.Valor);

                case "EmpleadoAdministrativo":
                    var administrativo = await _usuarioService.ObtenerAdministrativoPorIdAsync(id);
                    ViewBag.Tipo = "EmpleadoAdministrativo";
                    return View("DetailsAdministrativo", administrativo.Valor);

                default:
                    ViewBag.Error = "Este usuario no pertenece al modulo de gestion de usuarios.";
                    return RedirectToAction(nameof(Index));
            }
        }

        // ---------------- Estudiante ----------------

        public IActionResult CrearEstudiante() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrearEstudiante(CrearEstudianteDto dto)
        {
            var resultado = await _usuarioService.RegistrarEstudianteAsync(dto with { CreadoPor = User.Identity?.Name });

            if (resultado.EsFallo)
            {
                ViewBag.Error = resultado.Error!.Mensaje;
                return View(dto);
            }

            return RedirectToAction(nameof(Index), new { tipo = "Estudiante" });
        }

        public async Task<IActionResult> EditarEstudiante(int id)
        {
            var estudiante = await _usuarioService.ObtenerEstudiantePorIdAsync(id);
            if (estudiante.EsFallo)
            {
                ViewBag.Error = estudiante.Error!.Mensaje;
                return RedirectToAction(nameof(Index));
            }

            var e = estudiante.Valor!;
            ViewBag.Id = id;
            return View(new ActualizarEstudianteDto(e.Nombre, e.Apellido, e.Correo, e.Telefono, e.Matricula, e.Carrera));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarEstudiante(int id, ActualizarEstudianteDto dto)
        {
            var resultado = await _usuarioService.ActualizarEstudianteAsync(id, dto);

            if (resultado.EsFallo)
            {
                ViewBag.Error = resultado.Error!.Mensaje;
                ViewBag.Id = id;
                return View(dto);
            }

            return RedirectToAction(nameof(Details), new { id });
        }

        // ---------------- Docente ----------------

        public IActionResult CrearDocente() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrearDocente(CrearEmpleadoDocenteDto dto)
        {
            var resultado = await _usuarioService.RegistrarEmpleadoDocenteAsync(dto with { CreadoPor = User.Identity?.Name });

            if (resultado.EsFallo)
            {
                ViewBag.Error = resultado.Error!.Mensaje;
                return View(dto);
            }

            return RedirectToAction(nameof(Index), new { tipo = "EmpleadoDocente" });
        }

        public async Task<IActionResult> EditarDocente(int id)
        {
            var docente = await _usuarioService.ObtenerDocentePorIdAsync(id);
            if (docente.EsFallo)
            {
                ViewBag.Error = docente.Error!.Mensaje;
                return RedirectToAction(nameof(Index));
            }

            var d = docente.Valor!;
            ViewBag.Id = id;
            return View(new ActualizarEmpleadoDocenteDto(
                d.Nombre, d.Apellido, d.Correo, d.Telefono, d.CodigoEmpleado, d.Departamento, d.Cargo, d.Especialidad, d.TipoContrato));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarDocente(int id, ActualizarEmpleadoDocenteDto dto)
        {
            var resultado = await _usuarioService.ActualizarEmpleadoDocenteAsync(id, dto);

            if (resultado.EsFallo)
            {
                ViewBag.Error = resultado.Error!.Mensaje;
                ViewBag.Id = id;
                return View(dto);
            }

            return RedirectToAction(nameof(Details), new { id });
        }

        // ---------------- Administrativo ----------------

        public IActionResult CrearAdministrativo() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrearAdministrativo(CrearEmpleadoAdministrativoDto dto)
        {
            var resultado = await _usuarioService.RegistrarEmpleadoAdministrativoAsync(dto with { CreadoPor = User.Identity?.Name });

            if (resultado.EsFallo)
            {
                ViewBag.Error = resultado.Error!.Mensaje;
                return View(dto);
            }

            return RedirectToAction(nameof(Index), new { tipo = "EmpleadoAdministrativo" });
        }

        public async Task<IActionResult> EditarAdministrativo(int id)
        {
            var administrativo = await _usuarioService.ObtenerAdministrativoPorIdAsync(id);
            if (administrativo.EsFallo)
            {
                ViewBag.Error = administrativo.Error!.Mensaje;
                return RedirectToAction(nameof(Index));
            }

            var a = administrativo.Valor!;
            ViewBag.Id = id;
            return View(new ActualizarEmpleadoAdministrativoDto(
                a.Nombre, a.Apellido, a.Correo, a.Telefono, a.CodigoEmpleado, a.Departamento, a.Cargo, a.AreaAdministrativa));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarAdministrativo(int id, ActualizarEmpleadoAdministrativoDto dto)
        {
            var resultado = await _usuarioService.ActualizarEmpleadoAdministrativoAsync(id, dto);

            if (resultado.EsFallo)
            {
                ViewBag.Error = resultado.Error!.Mensaje;
                ViewBag.Id = id;
                return View(dto);
            }

            return RedirectToAction(nameof(Details), new { id });
        }

        // ---------------- Eliminar (comun a los 3 tipos) ----------------

        public async Task<IActionResult> Delete(int id)
        {
            var resumen = await _usuarioService.ObtenerPorIdAsync(id);
            if (resumen.EsFallo)
            {
                ViewBag.Error = resumen.Error!.Mensaje;
                return RedirectToAction(nameof(Index));
            }

            return View(resumen.Valor);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, EliminarDto dto)
        {
            var resultado = await _usuarioService.EliminarAsync(id, dto);

            if (resultado.EsFallo)
                TempData["Error"] = resultado.Error!.Mensaje;

            return RedirectToAction(nameof(Index));
        }
    }
}
